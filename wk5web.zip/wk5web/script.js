// ----------------------------
// Part 1: Variables & Conditionals
// ----------------------------
let cart = [];
let total = 0;
let cartTotal = 5200;
let bonusMessage = "";

// Free beanie check
if (cartTotal > 4000) {
  bonusMessage = "🎁 You get a FREE Beanie Hat with your order!";
} else {
  bonusMessage = "Add more items worth KES " + (4000 - cartTotal) + " to get a FREE Beanie Hat!";
}
let welcomeMessage = "JOIN THE MOVEMENT, SHOP TODAY!";

console.log(welcomeMessage);

// ----------------------------
// Part 2: Functions
// ----------------------------

// Function 1: Add item to cart
function addToCart(item, price) {
  cart.push({ item, price });
  total += price;
  updateCart();
}

// Function 2: Calculate discount
function calculateDiscount(amount) {
  if (amount > 5000) {
    return amount * 0.9; // 10% discount
  }
  return amount;
}

// ----------------------------
// Part 3: Loops
// ----------------------------

// Example loop to display cart
function updateCart() {
  let cartList = document.getElementById("cart-items");
  cartList.innerHTML = "";

  // Loop through cart array
  for (let i = 0; i < cart.length; i++) {
    let li = document.createElement("li");
    li.textContent = `${cart[i].item} - KES ${cart[i].price}`;
    cartList.appendChild(li);
  }

  // Update total
  document.getElementById("total").textContent = "Total: KES " + total;
}

// Example of while loop (simple countdown in console)
let countdown = 3;
while (countdown > 0) {
  console.log("Checkout in " + countdown + "...");
  countdown--;
}

// ----------------------------
// Part 4: DOM Manipulation
// ----------------------------

// DOM interaction 1: Display welcome message
let header = document.querySelector("header p");
header.textContent = welcomeMessage;

// DOM interaction 2: Toggle checkout button visibility
function checkout() {
  let finalAmount = calculateDiscount(total);
  document.getElementById("total").textContent =
    "Final Total after discount (if any): KES " + finalAmount;

  let cartSection = document.getElementById("cart");
  cartSection.style.backgroundColor = "#d4edda"; // change color
  cartSection.style.border = "2px solid green";

  // DOM interaction 3: Clear cart dynamically
  document.getElementById("cart-items").innerHTML = "<li>✅ Ready to bring this home? Complete your order below</li>";
  cart = [];
  total = 0;

  // Show order form
  document.getElementById("order-form").style.display = "block";
}

// ----------------------------
// New: Handle Customer Details Form
// ----------------------------
document.getElementById("customer-form").addEventListener("submit", function(e) {
  e.preventDefault();

  let name = document.getElementById("name").value;
  let email = document.getElementById("email").value;
  let payment = document.getElementById("payment").value;

  // Display confirmation
  document.getElementById("order-form").innerHTML = `
    <h2>🎉 Thank You Mkurugenzi!</h2>
    <p>Your order is in—can’t wait for you to enjoy it!.</p>
    <p><strong>Name:</strong> ${name}</p>
    <p><strong>Email:</strong> ${email}</p>
    <p><strong>Payment Method:</strong> ${payment}</p>
  `;
});
